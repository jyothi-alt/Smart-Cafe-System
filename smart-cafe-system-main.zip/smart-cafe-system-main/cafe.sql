CREATE database cafe;
use cafe;


CREATE TABLE employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room VARCHAR(255) UNIQUE,
    name VARCHAR(255),
    mail VARCHAR(255),
    mob VARCHAR(255),
    address TEXT
);

CREATE TABLE login_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user VARCHAR(255),
    password VARCHAR(255),
    employee_id INT,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL
);

CREATE TABLE bill (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bill_no VARCHAR(255),
    employee_id INT,
    bill TEXT,
    status VARCHAR(255),
    total INT,
    date DATE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL
);

CREATE TABLE feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT,
    sub VARCHAR(255),
    msg TEXT,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL
);

CREATE TABLE daily_revenue (
    rev_date DATE PRIMARY KEY,
    total_amount INT
);

CREATE TABLE employee_login_logout_time (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    time DATETIME NOT NULL,
    status varchar(20),
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

CREATE TABLE deleted_employees (
    deleted_id INT AUTO_INCREMENT PRIMARY KEY, 
    employee_id INT,                           
    room VARCHAR(255),
    name VARCHAR(255),
    mail VARCHAR(255),
    mob VARCHAR(255),
    address TEXT,
    deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL
);
