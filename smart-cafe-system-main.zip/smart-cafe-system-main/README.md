# smart-cafe-system

  It's a Python Tkinter Project
  
## Demo Screenshort

![scs1](https://user-images.githubusercontent.com/119858092/205630310-784f1df0-1a0f-44e4-b3c4-57c33168cba8.png)
